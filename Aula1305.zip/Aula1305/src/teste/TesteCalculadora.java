package teste;

import java.util.Scanner;

import classes.Calculadora;
import classes.CalculadoraCientifica;
import classes.Menu;

public class TesteCalculadora {

	// OPCOES DO MENU
	private static final int SOMA = 1;

	private static final int SUBTRACAO = 2;

	private static final int MULTIPLICACAO = 3;

	private static final int DIVISAO = 4;

	private static final int RAIZ_QUADRADA = 5;

	public static void main(final String[] args) {

		final Scanner scanner = new Scanner(System.in);

		int opcao;
		double operador1;
		double operador2;
		final Calculadora calculadora = new CalculadoraCientifica();

		do {

			Menu.exibirMenu();

			opcao = Menu.getOpcao();

			System.out.println("Digite o operador 1: ");
			operador1 = Menu.getOperador();

			System.out.println("Digite o operador 2: ");
			operador2 = Menu.getOperador();

			switch (opcao) {
			case SOMA:
				System.out.println(calculadora.somar(operador1, operador2));
				break;

			case SUBTRACAO:
				System.out.println(calculadora.subtrair(operador1, operador2));
				break;

			case MULTIPLICACAO:
				System.out.println(calculadora.multiplicar(operador1, operador2));
				break;

			case DIVISAO:
				System.out.println(calculadora.dividir(operador1, operador2));
				break;

			case RAIZ_QUADRADA:
				System.out.println(((CalculadoraCientifica) calculadora).raizQuadrada(operador1));
				break;

			default:
				System.out.println("Xau");
				break;
			}
		} while (opcao != 0);
	}

}
