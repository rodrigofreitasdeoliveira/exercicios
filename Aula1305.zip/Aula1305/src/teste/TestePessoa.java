package teste;

import classes.Pessoa;

public class TestePessoa {

	public static void main(final String[] args) {

	    final Pessoa pessoa = new Pessoa();
		pessoa.setIdade(26);
		pessoa.setNome("Harlan");
		pessoa.setPeso(67);
		pessoa.setSexo("Masculino");
		
		System.out.println(pessoa.getPeso());

	}

}
