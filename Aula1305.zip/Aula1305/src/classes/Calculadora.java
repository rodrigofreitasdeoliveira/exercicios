package classes;

public class Calculadora {

	public double somar(final double op1, final double op2) {

		return op1 + op2;
	}

	public double subtrair(final double op1, final double op2) {

		return op1 - op2;
	}

	public double multiplicar(final double op1, final double op2) {

		return op1 * op2;
	}

	public double dividir(final double op1, final double op2) {

		return op1 / op2;
	}

}
