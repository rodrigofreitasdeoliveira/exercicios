package classes;

public class CalculadoraCientifica extends Calculadora {

	public double raizQuadrada(final double valor) {

		return Math.sqrt(valor);
	}
}
