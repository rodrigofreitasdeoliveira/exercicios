package classes;

import java.util.Scanner;

public class Menu {

	public static void exibirMenu() {

		System.out.println("MENU");
		System.out.println("(1) Somar");
		System.out.println("(2) Subtrair");
		System.out.println("(3) Multiplicar");
		System.out.println("(4) Dividir");
		System.out.println("(5) Raiz Quadrada");
		System.out.println("(0) Sair");
	}

	public static int getOpcao() {

		final Scanner scanner = new Scanner(System.in);

		int opcao;

		do {

			opcao = scanner.nextInt();

			if (opcao < 0 || opcao > 5) {
				System.out.println("Opcao invalida! Digite um valor v�lido!");
			}
		} while (opcao < 0 || opcao > 5);

		return opcao;
	}

	public static double getOperador() {

		final Scanner scanner = new Scanner(System.in);

		double operador;

		do {

			operador = scanner.nextDouble();

			if (operador <= 0) {
				System.out.println("Opcao invalida! Digite um valor maior que zero!");
			}
		} while (operador <= 0);

		return operador;
	}
}
