package classes;

public class Pessoa {

	private int idade;

	private String nome;

	private String sexo;

	private double peso;

	public void andar() {

		System.out.println("Estou andando.");
	}

	public void falar() {

		System.out.println("bla bla bla");
	}

	void pular() {

		System.out.println("estou pulando");
	}

	public int getIdade() {

		return this.idade;
	}

	public void setIdade(final int idade) {

		this.idade = idade;
	}

	public String getNome() {

		return this.nome;
	}

	public void setNome(final String nome) {

		this.nome = nome;
	}

	public String getSexo() {

		return this.sexo;
	}

	public void setSexo(final String sexo) {

		this.sexo = sexo;
	}

	public double getPeso() {

		return this.peso;
	}

	public void setPeso(final double peso) {

		this.peso = peso;
	}

}
